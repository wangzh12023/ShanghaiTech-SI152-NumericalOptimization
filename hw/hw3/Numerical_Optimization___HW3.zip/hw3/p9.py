import numpy as np
import csv

# ================================
# 1. Load CSV data
# ================================
def load_data(filename):
    data = []
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)  # skip header if present
        for row in reader:
            data.append([float(x) for x in row])
    data = np.array(data)
    X = data[:, :10]
    y = data[:, 10].reshape(-1, 1)
    
    # Normalize (zero mean, unit variance)
    X = (X - np.mean(X, axis=0)) / (np.std(X, axis=0) + 1e-8)
    
    # Split train/test (80/20) with random permutation
    n = X.shape[0]
    n_train = int(0.8 * n)
    indices = np.random.permutation(n)
    X, y = X[indices], y[indices]
    
    X_train, y_train = X[:n_train], y[:n_train]
    X_test, y_test = X[n_train:], y[n_train:]
    return X_train, y_train, X_test, y_test


# ================================
# 2. Utility functions
# ================================
def sigmoid(z):
    return 1 / (1 + np.exp(-z))

def binary_cross_entropy(y, p):
    eps = 1e-8  
    p = np.clip(p, eps, 1 - eps)
    return -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))

def accuracy(y, y_pred):
    return np.mean(y == y_pred)

# ...


# ================================
# 3.1 Logistic regression (GD + line search)
# ================================
def logistic_regression_line_search(X, y, tol=1e-6, max_iter=500):
    n, d = X.shape
    w = np.zeros((d, 1))
    b = 0.0
    
    # TODO: implement the gd with line search
    
    return w, b


# ================================
# 3.2 Logistic regression (GD + fix step size)
# ================================
def logistic_regression_fixed_step_size(X, y, step=0.1, tol=1e-6, max_iter=500):
    n, d = X.shape
    w = np.zeros((d, 1))
    b = 0.0
    
    # TODO: implement the gd with fix step size
    
    return w, b


# ================================
# 4.1 L1 Logistic Regression (ISTA)
# ================================
def l1_logistic_regression_ISTA(X, y, lam=0.1, tol=1e-6, max_iter=500):
    n, d = X.shape
    w = np.zeros((d, 1))
    b = 0.0
    
    # TODO: implement the ISTA
    
    return w, b


# ================================
# 4.2 L1 Logistic Regression (subgradient)
# ================================
def l1_logistic_regression_subgradient(X, y, lam=0.1, tol=1e-6, max_iter=500):
    n, d = X.shape
    w = np.zeros((d, 1))
    b = 0.0
    
    # TODO: implement the subgradient method
    
    return w, b


# ================================
# 5. Main function: Train and show results
# ================================
if __name__ == "__main__":
    X_train, y_train, X_test, y_test = load_data("p9.csv")

    # w,b = logistic_regression_line_search(X_train, y_train)
    
    # TODO: train and compare the algorithms
    
    pass
